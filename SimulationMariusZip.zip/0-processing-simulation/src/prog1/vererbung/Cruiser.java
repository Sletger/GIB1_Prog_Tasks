/*package prog1.vererbung;


import java.util.Random;

import processing.core.PApplet;
import processing.core.PImage;

public class Cruiser extends Actor {
	protected PImage img;

	public Cruiser(PApplet context, String image)  {
		super(context);
		img =  context.loadImage(image);
	}
	
	
	
	public void display() {
		context.image(img, positionX, positionY);
	}
	
	
}
*/